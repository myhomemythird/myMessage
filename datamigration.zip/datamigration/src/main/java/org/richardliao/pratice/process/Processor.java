package org.richardliao.pratice.process;

import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;

public class Processor {

    private Strategy strategy = null;

    public Processor(Strategy strategy) {
	this.strategy = strategy;
    }

    public Map<String, String> start(Map<String, String> map) {
	if (null == map) return null;
	Map<String, String> res = new HashMap<>();
	Iterator<Map.Entry<String, String>> iKeyVal = map.entrySet().iterator();
	while (iKeyVal.hasNext()) {
	    Map.Entry<String, String> keyVal = iKeyVal.next();
	    String[] ary = this.strategy.process(new String[]{keyVal.getKey(), keyVal.getValue()});
	    if (null == ary || ary.length < 2) continue;
	    res.put(ary[0], ary[1]);
	}
	return res;
    }
	
    public static interface Strategy {
	public String[] process(String[] keyVal);
    }
}
