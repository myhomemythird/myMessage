package org.richardliao.pratice;

import java.util.Map;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.richardliao.pratice.process.Processor;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        Map<String, String> map = new HashMap<>();
	map.put("oldCol", "1");
	System.out.println((new Processor(new Copied()).start(map)));
	System.out.println((new Processor(new Minus()).start(map)));
	System.out.println((new Processor(new IfLogic()).start(map)));
    }

    public static class Copied implements Processor.Strategy {
	public String[] process(String[] ary) {
	    return ary;
	}
    }

    public static class Minus implements Processor.Strategy {
	public String[] process(String[] ary) {
	    if (null == ary) return null;
	    String[] res = new String[ary.length];
	    res[0] = ary[0];
	    res[1] = "-" + ary[1];
	    return res;
	}
    }

    public static class IfLogic implements Processor.Strategy {
	private static final String IF_SCRIPT_PATTERN = "@IF\\((.+),(.+),(.+)\\)";
	private String ifScript = "newCol<=@IF(oldCol==1, 10, 20)";
	
	public String[] process(String[] ary) {
	    if (null == ary) return null;
	    String[] res = new String[ary.length];
	    res[0] = getKey(this.ifScript);
	    res[1] = getValue(this.ifScript, ary);
	    return res;
	}

	private String getKey(String script) {
	    if (null == script || "".equals(script.trim())) return null;
	    if (script.indexOf("<=") < 0) return "";
	    return script.split("<=")[0];
	}

	private String getValue(String script, String[] ary) {
	    if (null == script || "".equals(script.trim()) || null == ary) return null;
	    if (script.indexOf("<=") < 0) return "";
	    String str = script.split("<=")[1];
	    System.out.print("str=" + str);
	    Pattern pattern = Pattern.compile("^" + IF_SCRIPT_PATTERN + "$");
	    Matcher m = pattern.matcher(str);
	    if (!m.find() || m.groupCount() < 3) return "";
	    System.out.print("test...");
	    String test = m.group(1);
	    String resTrue = m.group(2);
	    String resFalse = m.group(3);
	    return (doTest(test, ary) ? resTrue : resFalse);
	}

	private boolean doTest(String test, String[] ary) {
	    if (null == test || "".equals(test.trim())) return false;
	    if (test.indexOf("==") < 0) return false;
	    String[] res = test.split("==");
	    if (null == res || res.length < 2) return false;
	    if(res[0].equals(ary[0]) && res[1].equals(ary[1]))
		return true;
	    else
		return false;
	}
    }
}
